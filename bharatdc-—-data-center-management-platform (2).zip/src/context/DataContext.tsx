import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  DataCenter,
  Rack,
  Server,
  Client,
  ServerAllocation,
  MaintenanceRecord,
  Organization,
  User,
  ActivityLog,
  NotificationItem,
  ReportItem,
  DashboardStats,
  ServerStatus
} from '../types';
import { loadInitialData, storage } from '../services/storageService';
import {
  INITIAL_DATA_CENTERS,
  INITIAL_RACKS,
  INITIAL_SERVERS,
  INITIAL_CLIENTS,
  INITIAL_ALLOCATIONS,
  INITIAL_MAINTENANCE,
  INITIAL_ORGANIZATIONS,
  INITIAL_USERS,
  INITIAL_ACTIVITY,
  INITIAL_NOTIFICATIONS,
  INITIAL_REPORTS
} from '../services/mockData';

export interface Toast {
  id: string;
  type: 'success' | 'info' | 'error';
  message: string;
}

interface DataContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  dataCenters: DataCenter[];
  racks: Rack[];
  servers: Server[];
  clients: Client[];
  allocations: ServerAllocation[];
  maintenance: MaintenanceRecord[];
  organizations: Organization[];
  users: User[];
  activity: ActivityLog[];
  activities: ActivityLog[];
  notifications: NotificationItem[];
  reports: ReportItem[];
  stats: DashboardStats;
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'info' | 'error') => void;
  dismissToast: (id: string) => void;
  removeToast: (id: string) => void;
  // Simulation switches for reviewers
  simulateLoading: boolean;
  setSimulateLoading: (val: boolean) => void;
  simulateError: boolean;
  setSimulateError: (val: boolean) => void;
  
  // Server actions
  addServer: (server: Omit<Server, 'id'>) => void;
  updateServer: (id: string, updates: Partial<Server>) => void;
  deleteServer: (id: string) => void;
  
  // Data Center actions
  addDataCenter: (dc: Omit<DataCenter, 'id'>) => void;
  updateDataCenter: (id: string, updates: Partial<DataCenter>) => void;
  deleteDataCenter: (id: string) => void;

  // Rack actions
  addRack: (rack: Omit<Rack, 'id'>) => void;
  updateRack: (id: string, updates: Partial<Rack>) => void;
  deleteRack: (id: string) => void;

  // Client actions
  addClient: (client: Omit<Client, 'id'>) => void;
  updateClient: (id: string, updates: Partial<Client>) => void;
  deleteClient: (id: string) => void;

  // Allocation actions (UX: "Remove Assignment" instead of Deallocate)
  allocateServer: (data: { serverId: string; clientId: string; purpose: string; bandwidthQuotaTb: number; billingCycle: string }) => boolean;
  removeAssignment: (allocationId: string) => void;

  // Maintenance actions (UX: "Start Maintenance")
  addMaintenance: (record: Omit<MaintenanceRecord, 'id' | 'ticketNumber' | 'status'>) => void;
  startMaintenance: (recordId: string) => void;
  completeMaintenance: (recordId: string) => void;
  cancelMaintenance: (recordId: string) => void;

  // Organization actions
  addOrganization: (org: Omit<Organization, 'id'>) => void;
  updateOrganization: (id: string, updates: Partial<Organization>) => void;
  deleteOrganization: (id: string) => void;

  // User actions
  addUser: (user: Omit<User, 'id' | 'lastLogin'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Notification actions
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  // Report actions
  generateReport: (title: string, type: ReportItem['type'], period: string) => void;

  // Global reset
  resetDemoData: () => void;
  resetToMockData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const initial = loadInitialData();

  const [users, setUsers] = useState<User[]>(initial.users);
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    return initial.users[0] || {
      id: 'usr-admin',
      fullName: 'Rajesh Verma',
      name: 'Rajesh Verma',
      email: 'rajesh.verma@bharatdc.in',
      role: 'Admin',
      assignedDataCenter: 'BHARATDC Mumbai West (MUM-1)',
      status: 'Active',
      lastLogin: '2026-09-18 10:14 IST',
      phone: '+91 22 2400 9001'
    };
  });
  const [dataCenters, setDataCenters] = useState<DataCenter[]>(initial.dataCenters);
  const [racks, setRacks] = useState<Rack[]>(initial.racks);
  const [servers, setServers] = useState<Server[]>(initial.servers);
  const [clients, setClients] = useState<Client[]>(initial.clients);
  const [allocations, setAllocations] = useState<ServerAllocation[]>(initial.allocations);
  const [maintenance, setMaintenance] = useState<MaintenanceRecord[]>(initial.maintenance);
  const [organizations, setOrganizations] = useState<Organization[]>(initial.organizations);
  const [activity, setActivity] = useState<ActivityLog[]>(initial.activity);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initial.notifications);
  const [reports, setReports] = useState<ReportItem[]>(initial.reports);

  const [toasts, setToasts] = useState<Toast[]>([]);
  const [simulateLoading, setSimulateLoading] = useState<boolean>(false);
  const [simulateError, setSimulateError] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => { storage.set('dataCenters', dataCenters); }, [dataCenters]);
  useEffect(() => { storage.set('racks', racks); }, [racks]);
  useEffect(() => { storage.set('servers', servers); }, [servers]);
  useEffect(() => { storage.set('clients', clients); }, [clients]);
  useEffect(() => { storage.set('allocations', allocations); }, [allocations]);
  useEffect(() => { storage.set('maintenance', maintenance); }, [maintenance]);
  useEffect(() => { storage.set('organizations', organizations); }, [organizations]);
  useEffect(() => { storage.set('users', users); }, [users]);
  useEffect(() => { storage.set('activity', activity); }, [activity]);
  useEffect(() => { storage.set('notifications', notifications); }, [notifications]);
  useEffect(() => { storage.set('reports', reports); }, [reports]);

  const showToast = useCallback((message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const logActivity = useCallback((action: string, targetType: ActivityLog['targetType'], targetName: string, details: string) => {
    const newLog: ActivityLog = {
      id: 'act-' + Date.now(),
      timestamp: 'Just now',
      userName: 'Rajesh Verma',
      action,
      targetType,
      targetName,
      details
    };
    setActivity(prev => [newLog, ...prev]);
  }, []);

  // Server management
  const addServer = useCallback((serverData: Omit<Server, 'id'>) => {
    const id = 'srv-' + Date.now();
    const newServer: Server = { ...serverData, id };
    setServers(prev => [newServer, ...prev]);
    logActivity('Add Server', 'Server', newServer.assetTag, `Created server ${newServer.hostname} with status ${newServer.status}`);
    showToast(`Server ${newServer.assetTag} added successfully.`);
  }, [logActivity, showToast]);

  const updateServer = useCallback((id: string, updates: Partial<Server>) => {
    setServers(prev => prev.map(s => (s.id === id ? { ...s, ...updates } : s)));
    const target = servers.find(s => s.id === id);
    if (target) {
      logActivity('Server Updated', 'Server', target.assetTag, `Updated details for ${target.hostname}`);
      showToast(`Server ${target.assetTag} updated successfully.`);
    }
  }, [servers, logActivity, showToast]);

  const deleteServer = useCallback((id: string) => {
    const target = servers.find(s => s.id === id);
    setServers(prev => prev.filter(s => s.id !== id));
    // Also clean up any allocations
    setAllocations(prev => prev.filter(a => a.serverId !== id));
    if (target) {
      logActivity('Server Deleted', 'Server', target.assetTag, `Removed server ${target.hostname} from inventory`);
      showToast(`Server ${target.assetTag} deleted permanently.`);
    }
  }, [servers, logActivity, showToast]);

  // Data Center management
  const addDataCenter = useCallback((dcData: Omit<DataCenter, 'id'>) => {
    const id = 'dc-' + Date.now();
    const newDc: DataCenter = { ...dcData, id };
    setDataCenters(prev => [newDc, ...prev]);
    logActivity('Add Data Center', 'Data Center', newDc.name, `Added facility in ${newDc.city}`);
    showToast(`Data Center ${newDc.name} added successfully.`);
  }, [logActivity, showToast]);

  const updateDataCenter = useCallback((id: string, updates: Partial<DataCenter>) => {
    setDataCenters(prev => prev.map(d => (d.id === id ? { ...d, ...updates } : d)));
    const target = dataCenters.find(d => d.id === id);
    if (target) {
      showToast(`Data Center ${target.name} updated.`);
    }
  }, [dataCenters, showToast]);

  const deleteDataCenter = useCallback((id: string) => {
    const target = dataCenters.find(d => d.id === id);
    setDataCenters(prev => prev.filter(d => d.id !== id));
    if (target) {
      logActivity('Data Center Removed', 'Data Center', target.name, `Removed facility ${target.name}`);
      showToast(`Data Center ${target.name} removed.`);
    }
  }, [dataCenters, logActivity, showToast]);

  // Rack management
  const addRack = useCallback((rackData: Omit<Rack, 'id'>) => {
    const id = 'rack-' + Date.now();
    const newRack: Rack = { ...rackData, id };
    setRacks(prev => [newRack, ...prev]);
    logActivity('Add Rack', 'Rack', newRack.rackNumber, `Commissioned in ${newRack.dataCenterName}`);
    showToast(`Rack ${newRack.rackNumber} added.`);
  }, [logActivity, showToast]);

  const updateRack = useCallback((id: string, updates: Partial<Rack>) => {
    setRacks(prev => prev.map(r => (r.id === id ? { ...r, ...updates } : r)));
    showToast('Rack updated successfully.');
  }, [showToast]);

  const deleteRack = useCallback((id: string) => {
    const target = racks.find(r => r.id === id);
    setRacks(prev => prev.filter(r => r.id !== id));
    if (target) {
      logActivity('Rack Deleted', 'Rack', target.rackNumber, `Removed from ${target.dataCenterName}`);
      showToast(`Rack ${target.rackNumber} deleted.`);
    }
  }, [racks, logActivity, showToast]);

  // Client management
  const addClient = useCallback((clientData: Omit<Client, 'id'>) => {
    const id = 'client-' + Date.now();
    const newClient: Client = { ...clientData, id };
    setClients(prev => [newClient, ...prev]);
    logActivity('Add Client', 'Client', newClient.name, `Registered client under ${newClient.organization}`);
    showToast(`Client ${newClient.name} added successfully.`);
  }, [logActivity, showToast]);

  const updateClient = useCallback((id: string, updates: Partial<Client>) => {
    setClients(prev => prev.map(c => (c.id === id ? { ...c, ...updates } : c)));
    showToast('Client details updated.');
  }, [showToast]);

  const deleteClient = useCallback((id: string) => {
    const target = clients.find(c => c.id === id);
    setClients(prev => prev.filter(c => c.id !== id));
    if (target) {
      logActivity('Client Removed', 'Client', target.name, `Archived client account`);
      showToast(`Client ${target.name} removed.`);
    }
  }, [clients, logActivity, showToast]);

  // Allocation management: allocateServer & removeAssignment
  const allocateServer = useCallback((data: { serverId: string; clientId: string; purpose: string; bandwidthQuotaTb: number; billingCycle: string }) => {
    const server = servers.find(s => s.id === data.serverId);
    const client = clients.find(c => c.id === data.clientId);
    if (!server || !client) return false;

    const newAlloc: ServerAllocation = {
      id: 'alloc-' + Date.now(),
      serverId: server.id,
      serverHostname: server.hostname,
      assetTag: server.assetTag,
      clientId: client.id,
      clientName: client.name,
      dataCenterName: server.dataCenterName,
      assignedDate: new Date().toISOString().split('T')[0],
      billingCycle: data.billingCycle,
      purpose: data.purpose,
      bandwidthQuotaTb: data.bandwidthQuotaTb,
      status: 'Active'
    };

    setAllocations(prev => [newAlloc, ...prev]);
    // Update server status to 'In Use'
    setServers(prev => prev.map(s => (s.id === server.id ? { ...s, status: 'In Use' as ServerStatus, allocatedClientId: client.id, clientName: client.name } : s)));
    // Update client count
    setClients(prev => prev.map(c => (c.id === client.id ? { ...c, activeAllocationsCount: c.activeAllocationsCount + 1 } : c)));

    logActivity('Server Allocated', 'Allocation', server.assetTag, `Assigned to ${client.name} for ${data.purpose}`);
    showToast(`Server ${server.assetTag} assigned to ${client.name}.`);
    return true;
  }, [servers, clients, logActivity, showToast]);

  const removeAssignment = useCallback((allocationId: string) => {
    const alloc = allocations.find(a => a.id === allocationId);
    if (!alloc) return;

    setAllocations(prev => prev.filter(a => a.id !== allocationId));
    // Reset server status to 'Available'
    setServers(prev => prev.map(s => (s.id === alloc.serverId ? { ...s, status: 'Available' as ServerStatus, allocatedClientId: undefined, clientName: undefined } : s)));
    // Decrement client count
    setClients(prev => prev.map(c => (c.id === alloc.clientId ? { ...c, activeAllocationsCount: Math.max(0, c.activeAllocationsCount - 1) } : c)));

    logActivity('Remove Assignment', 'Allocation', alloc.assetTag, `Unlinked from client ${alloc.clientName}`);
    showToast(`Assignment removed for ${alloc.assetTag}. Server is now Available.`);
  }, [allocations, logActivity, showToast]);

  // Maintenance management: addMaintenance, startMaintenance, completeMaintenance, cancelMaintenance
  const addMaintenance = useCallback((recordData: Omit<MaintenanceRecord, 'id' | 'ticketNumber' | 'status'>) => {
    const ticketNumber = `MNT-2026-${Math.floor(100 + Math.random() * 900)}`;
    const newRecord: MaintenanceRecord = {
      ...recordData,
      id: 'maint-' + Date.now(),
      ticketNumber,
      status: 'Scheduled'
    };

    setMaintenance(prev => [newRecord, ...prev]);
    logActivity('Maintenance Scheduled', 'Maintenance', ticketNumber, `${newRecord.title} at ${newRecord.dataCenterName}`);
    showToast(`Maintenance ticket ${ticketNumber} created.`);
  }, [logActivity, showToast]);

  const startMaintenance = useCallback((recordId: string) => {
    const record = maintenance.find(m => m.id === recordId);
    if (!record) return;

    setMaintenance(prev => prev.map(m => (m.id === recordId ? { ...m, status: 'In Progress' } : m)));

    // If linked to a server, set server status to Under Maintenance
    if (record.serverId) {
      setServers(prev => prev.map(s => (s.id === record.serverId ? { ...s, status: 'Under Maintenance' as ServerStatus } : s)));
    }

    logActivity('Start Maintenance', 'Maintenance', record.ticketNumber, `Technician ${record.technician} started work.`);
    showToast(`Maintenance started for ${record.ticketNumber}.`);
  }, [maintenance, logActivity, showToast]);

  const completeMaintenance = useCallback((recordId: string) => {
    const record = maintenance.find(m => m.id === recordId);
    if (!record) return;

    setMaintenance(prev => prev.map(m => (m.id === recordId ? { ...m, status: 'Completed' } : m)));

    // If linked to a server, set server status back to Available or In Use if allocated
    if (record.serverId) {
      setServers(prev => prev.map(s => {
        if (s.id === record.serverId) {
          const restoredStatus: ServerStatus = s.allocatedClientId ? 'In Use' : 'Available';
          return { ...s, status: restoredStatus };
        }
        return s;
      }));
    }

    logActivity('Maintenance Completed', 'Maintenance', record.ticketNumber, `Ticket resolved and closed.`);
    showToast(`Maintenance ticket ${record.ticketNumber} marked as completed.`);
  }, [maintenance, logActivity, showToast]);

  const cancelMaintenance = useCallback((recordId: string) => {
    const record = maintenance.find(m => m.id === recordId);
    if (!record) return;

    setMaintenance(prev => prev.map(m => (m.id === recordId ? { ...m, status: 'Cancelled' } : m)));

    // Restore server status if ticket was in progress
    if (record.serverId && record.status === 'In Progress') {
      setServers(prev => prev.map(s => {
        if (s.id === record.serverId) {
          const restoredStatus: ServerStatus = s.allocatedClientId ? 'In Use' : 'Available';
          return { ...s, status: restoredStatus };
        }
        return s;
      }));
    }

    showToast(`Maintenance ticket ${record.ticketNumber} cancelled.`);
  }, [maintenance, showToast]);

  // Organization management
  const addOrganization = useCallback((orgData: Omit<Organization, 'id'>) => {
    const id = 'org-' + Date.now();
    const newOrg: Organization = { ...orgData, id };
    setOrganizations(prev => [newOrg, ...prev]);
    logActivity('Add Organization', 'Data Center', newOrg.name, `New partner org created`);
    showToast(`Organization ${newOrg.name} added.`);
  }, [logActivity, showToast]);

  const updateOrganization = useCallback((id: string, updates: Partial<Organization>) => {
    setOrganizations(prev => prev.map(o => (o.id === id ? { ...o, ...updates } : o)));
    showToast('Organization updated.');
  }, [showToast]);

  const deleteOrganization = useCallback((id: string) => {
    const target = organizations.find(o => o.id === id);
    setOrganizations(prev => prev.filter(o => o.id !== id));
    if (target) {
      showToast(`Organization ${target.name} removed.`);
    }
  }, [organizations, showToast]);

  // User management
  const addUser = useCallback((userData: Omit<User, 'id' | 'lastLogin'>) => {
    const id = 'usr-' + Date.now();
    const newUser: User = { ...userData, id, lastLogin: 'Never' };
    setUsers(prev => [newUser, ...prev]);
    logActivity('User Added', 'User', newUser.fullName, `Created ${newUser.role} account`);
    showToast(`User ${newUser.fullName} added successfully.`);
  }, [logActivity, showToast]);

  const updateUser = useCallback((id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => (u.id === id ? { ...u, ...updates } : u)));
    showToast('User profile updated.');
  }, [showToast]);

  const deleteUser = useCallback((id: string) => {
    const target = users.find(u => u.id === id);
    setUsers(prev => prev.filter(u => u.id !== id));
    if (target) {
      logActivity('User Deleted', 'User', target.fullName, `Revoked system access`);
      showToast(`User ${target.fullName} deleted.`);
    }
  }, [users, logActivity, showToast]);

  // Notifications
  const markNotificationRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast('All notifications marked as read.');
  }, [showToast]);

  // Reports
  const generateReport = useCallback((title: string, type: ReportItem['type'], period: string) => {
    const id = 'rep-' + Date.now();
    const newReport: ReportItem = {
      id,
      title,
      type,
      period,
      generatedDate: new Date().toISOString().split('T')[0],
      generatedBy: 'Rajesh Verma',
      fileSize: '1.2 MB',
      status: 'Ready'
    };
    setReports(prev => [newReport, ...prev]);
    logActivity('Generate Report', 'Server', title, `Created ${type} report for ${period}`);
    showToast(`Report "${title}" generated successfully.`);
  }, [logActivity, showToast]);

  // Global reset
  const resetDemoData = useCallback(() => {
    storage.resetAll();
    setDataCenters(INITIAL_DATA_CENTERS);
    setRacks(INITIAL_RACKS);
    setServers(INITIAL_SERVERS);
    setClients(INITIAL_CLIENTS);
    setAllocations(INITIAL_ALLOCATIONS);
    setMaintenance(INITIAL_MAINTENANCE);
    setOrganizations(INITIAL_ORGANIZATIONS);
    setUsers(INITIAL_USERS);
    setActivity(INITIAL_ACTIVITY);
    setNotifications(INITIAL_NOTIFICATIONS);
    setReports(INITIAL_REPORTS);
    setSimulateLoading(false);
    setSimulateError(false);
    showToast('Application data reset to clean initial state.');
  }, [showToast]);

  // Calculated stats for dashboard
  const stats: DashboardStats = {
    totalServers: servers.length,
    availableServers: servers.filter(s => s.status === 'Available').length,
    serversInUse: servers.filter(s => s.status === 'In Use').length,
    serversUnderMaintenance: servers.filter(s => s.status === 'Under Maintenance').length,
    serversNotWorking: servers.filter(s => s.status === 'Not Working').length,
    totalClients: clients.length,
    totalDataCenters: dataCenters.length,
    totalRacks: racks.length,
  };

  return (
    <DataContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        dataCenters,
        racks,
        servers,
        clients,
        allocations,
        maintenance,
        organizations,
        users,
        activity,
        activities: activity,
        notifications,
        reports,
        stats,
        toasts,
        showToast,
        dismissToast,
        removeToast: dismissToast,
        simulateLoading,
        setSimulateLoading,
        simulateError,
        setSimulateError,
        addServer,
        updateServer,
        deleteServer,
        addDataCenter,
        updateDataCenter,
        deleteDataCenter,
        addRack,
        updateRack,
        deleteRack,
        addClient,
        updateClient,
        deleteClient,
        allocateServer,
        removeAssignment,
        addMaintenance,
        startMaintenance,
        completeMaintenance,
        cancelMaintenance,
        addOrganization,
        updateOrganization,
        deleteOrganization,
        addUser,
        updateUser,
        deleteUser,
        markNotificationRead,
        markAllNotificationsRead,
        generateReport,
        resetDemoData,
        resetToMockData: resetDemoData
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useDataCenter = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useDataCenter must be used within a DataProvider');
  }
  return context;
};
