import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { DataProvider, useDataCenter } from './context/DataContext';
import { AppLayout } from './components/layout/AppLayout';
import { ToastContainer } from './components/common/ToastContainer';

// Pages
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { Servers } from './pages/Servers';
import { ServerAllocationPage } from './pages/ServerAllocation';
import { MaintenancePage } from './pages/Maintenance';
import { DataCentersPage } from './pages/DataCenters';
import { RacksPage } from './pages/Racks';
import { ClientsPage } from './pages/Clients';
import { OrganizationsPage } from './pages/Organizations';
import { UsersPage } from './pages/Users';
import { ReportsPage } from './pages/Reports';
import { ActivityPage } from './pages/Activity';
import { NotificationsPage } from './pages/Notifications';
import { ProfilePage } from './pages/Profile';
import { SettingsPage } from './pages/Settings';

// Protected Route wrapper ensuring user is logged in
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useDataCenter();
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

// Public Route wrapper redirecting logged in user away from login
const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useDataCenter();
  if (currentUser) {
    return <Navigate to="/dashboard" replace />;
  }
  return <>{children}</>;
};

const AppContent: React.FC = () => {
  return (
    <>
      <Routes>
        {/* Public Landing Route */}
        <Route path="/" element={<Landing />} />

        {/* Public Login Route */}
        <Route
          path="/login"
          element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          }
        />

        {/* Protected Application Routes wrapped in AppLayout */}
        <Route
          element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/servers" element={<Servers />} />
          <Route path="/server-allocation" element={<ServerAllocationPage />} />
          <Route path="/maintenance" element={<MaintenancePage />} />
          <Route path="/data-centers" element={<DataCentersPage />} />
          <Route path="/racks" element={<RacksPage />} />
          <Route path="/clients" element={<ClientsPage />} />
          <Route path="/organizations" element={<OrganizationsPage />} />
          <Route path="/users" element={<UsersPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          <Route path="/activity" element={<ActivityPage />} />
          <Route path="/history" element={<Navigate to="/activity" replace />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>

        {/* Fallback route */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>

      <ToastContainer />
    </>
  );
};

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </BrowserRouter>
  );
};

export default App;
