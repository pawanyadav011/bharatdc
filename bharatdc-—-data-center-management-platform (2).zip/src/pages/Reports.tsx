import React, { useState, useMemo } from 'react';
import {
  FileText,
  Download,
  Clock,
  Zap,
  ShieldCheck,
  Server,
  Layers,
  Calendar,
  Eye,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import { useDataCenter } from '../context/DataContext';

export const ReportsPage: React.FC = () => {
  const { dataCenters, servers, clients, showToast } = useDataCenter();
  const [selectedFacility, setSelectedFacility] = useState('ALL');
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | 'custom'>('30d');
  const [activeReportId, setActiveReportId] = useState<string>('capacity');
  const [downloadingFormat, setDownloadingFormat] = useState<string | null>(null);

  const reportTemplates = [
    {
      id: 'capacity',
      title: 'Capacity & Utilization Report',
      code: 'REP-CAP-2026',
      description: 'Physical server occupancy, 42U rack allocations, unallocated blades, and hall headroom across facilities.',
      kpi: '78.4% Occupied',
      kpiSub: '+3.2% vs last cycle',
      frequency: 'Monthly / On-Demand',
      recordsCount: 42
    },
    {
      id: 'energy',
      title: 'Energy & PUE Efficiency Audit',
      code: 'REP-NRG-881',
      description: 'Power Usage Effectiveness (PUE) metrics, cooling chiller kW draw, solar generation, and carbon footprint.',
      kpi: '1.18 Avg PUE',
      kpiSub: 'Tier IV Green Certified',
      frequency: 'Monthly',
      recordsCount: 16
    },
    {
      id: 'sla',
      title: 'Client SLA Compliance Report',
      code: 'REP-SLA-0901',
      description: 'Institutional tenant bandwidth consumption, 99.999% uptime compliance, and incident response audit.',
      kpi: '99.98% Met',
      kpiSub: 'Zero breach penalties',
      frequency: 'Quarterly',
      recordsCount: 28
    },
    {
      id: 'lifecycle',
      title: 'Hardware Lifecycle & Maintenance Audit',
      code: 'REP-HW-EOL',
      description: 'Component wear telemetry, scheduled preventive work orders, warranty expirations, and replacement cycles.',
      kpi: '12 Assets in EOL Window',
      kpiSub: 'Maintenance planned',
      frequency: 'Bi-Annual',
      recordsCount: 35
    }
  ];

  const handleExport = (reportTitle: string, format: 'PDF' | 'CSV' | 'Excel') => {
    const exportId = `${reportTitle}-${format}`;
    setDownloadingFormat(exportId);
    setTimeout(() => {
      setDownloadingFormat(null);
      showToast(`${reportTitle} (${format}) generated and exported successfully.`);
    }, 1200);
  };

  // Preview data based on activeReportId
  const previewData = useMemo(() => {
    switch (activeReportId) {
      case 'capacity':
        return [
          { col1: 'MUM-1 (Server Hall A)', col2: '42U Rack 01-12', col3: '86% Capacity', col4: '14.2 kW', col5: 'Optimal' },
          { col1: 'DEL-2 (Main Hall)', col2: '42U Rack 01-08', col3: '74% Capacity', col4: '11.8 kW', col5: 'Optimal' },
          { col1: 'BLR-1 (Hall 2)', col2: '42U Rack 01-14', col3: '92% Capacity', col4: '16.5 kW', col5: 'High Density' },
          { col1: 'HYD-1 (Zone B)', col2: '42U Rack 01-06', col3: '65% Capacity', col4: '9.4 kW', col5: 'Available Space' }
        ];
      case 'energy':
        return [
          { col1: 'MUM-1 West', col2: '1.18 PUE', col3: '420.5 kW Total', col4: 'Solar 18%', col5: 'Optimal Thermal' },
          { col1: 'DEL-2 NCR', col2: '1.21 PUE', col3: '380.0 kW Total', col4: 'Grid Standard', col5: 'Optimal Thermal' },
          { col1: 'BLR-1 South', col2: '1.15 PUE', col3: '510.2 kW Total', col4: 'Solar 24%', col5: 'Best-in-Class' },
          { col1: 'HYD-1 Deccan', col2: '1.19 PUE', col3: '325.8 kW Total', col4: 'Solar 15%', col5: 'Optimal Thermal' }
        ];
      case 'sla':
        return [
          { col1: 'National Highways Authority', col2: '10 Nodes', col3: '42 TB / 50 TB', col4: '100.0% Uptime', col5: 'Compliant' },
          { col1: 'Central Bank Switch', col2: '8 Nodes', col3: '88 TB / 100 TB', col4: '99.999% Uptime', col5: 'Compliant' },
          { col1: 'Digital India Census Corp', col2: '14 Nodes', col3: '62 TB / 80 TB', col4: '99.98% Uptime', col5: 'Compliant' },
          { col1: 'State Power Grid Telecom', col2: '6 Nodes', col3: '28 TB / 40 TB', col4: '99.99% Uptime', col5: 'Compliant' }
        ];
      default:
        return [
          { col1: 'Dell PowerEdge R750 (SRV-01)', col2: 'MUM-1 U14', col3: '3.4 yrs in service', col4: 'Warranty Active', col5: 'Pass' },
          { col1: 'HP ProLiant DL380 (SRV-08)', col2: 'DEL-2 U22', col3: '4.8 yrs in service', col4: 'EOL in 60 Days', col5: 'Plan Upgrade' },
          { col1: 'Cisco UCS C240 (SRV-19)', col2: 'BLR-1 U08', col3: '2.1 yrs in service', col4: 'Warranty Active', col5: 'Pass' },
          { col1: 'Lenovo ThinkSystem (SRV-24)', col2: 'HYD-1 U18', col3: '3.0 yrs in service', col4: 'Warranty Active', col5: 'Pass' }
        ];
    }
  }, [activeReportId]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-base sm:text-lg font-semibold text-[#F8FAFC] tracking-tight">Intelligence & Operational Reports</h2>
        <p className="text-xs text-[#94A3B8] mt-0.5">
          Generate compliance audits, compute utilization analytics, and green energy audits for sovereign operations
        </p>
      </div>

      {/* Scope Toolbar & Date Range (Req 20) */}
      <div className="p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[#94A3B8] font-medium">Data Center:</span>
            <select
              value={selectedFacility}
              onChange={e => setSelectedFacility(e.target.value)}
              className="py-1.5 px-3 text-xs text-slate-200 bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Facilities ({dataCenters.length} Sites)</option>
              {dataCenters.map(dc => (
                <option key={dc.id} value={dc.id}>
                  {dc.name} ({dc.code})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-[#0A1424] p-1 rounded-lg border border-[rgba(148,163,184,0.14)]">
            {(['7d', '30d', '90d', 'custom'] as const).map(range => (
              <button
                key={range}
                type="button"
                onClick={() => setDateRange(range)}
                className={`px-2.5 py-1 rounded-md text-xs uppercase tracking-wider transition-colors ${
                  dateRange === range
                    ? 'bg-blue-600 text-white font-semibold shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {range === '7d' ? 'Last 7 Days' : range === '30d' ? 'Last 30 Days' : range === '90d' ? 'Last 90 Days' : 'Custom'}
              </button>
            ))}
          </div>
        </div>

        <div className="text-[11px] text-[#64748B] font-mono">
          Audit cycle timestamp: 04:00 IST • National Registry Synchronized
        </div>
      </div>

      {/* 4 Report Cards with Summary KPIs (Req 20) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reportTemplates.map(template => {
          const isSelected = activeReportId === template.id;
          return (
            <div
              key={template.id}
              onClick={() => setActiveReportId(template.id)}
              className={`p-5 bg-[#101C30] border rounded-xl shadow-lg flex flex-col justify-between space-y-4 cursor-pointer transition-all ${
                isSelected
                  ? 'border-blue-500 shadow-[0_0_16px_rgba(37,99,235,0.15)] bg-[#122038]'
                  : 'border-[rgba(148,163,184,0.14)] hover:border-[rgba(148,163,184,0.25)] hover:bg-[#122038]/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] text-blue-400 font-semibold px-2.5 py-0.5 bg-[#0A1424] border border-blue-500/20 rounded-md">
                    {template.code}
                  </span>
                  <span className="text-[11px] text-[#94A3B8]">{template.frequency}</span>
                </div>
                <h3 className="font-semibold text-[#F8FAFC] text-sm mt-3">{template.title}</h3>
                <p className="text-xs text-[#94A3B8] mt-1 leading-relaxed">{template.description}</p>
              </div>

              {/* KPI highlight block */}
              <div className="p-3 bg-[#0D1728] border border-[rgba(148,163,184,0.1)] rounded-lg flex items-center justify-between font-mono text-xs">
                <div>
                  <div className="text-[#F8FAFC] font-bold text-sm">{template.kpi}</div>
                  <div className="text-[10px] text-emerald-400 font-sans mt-0.5">{template.kpiSub}</div>
                </div>
                <span className="text-[11px] text-slate-500 font-sans">{template.recordsCount} Records</span>
              </div>

              {/* Export Actions: PDF, CSV, Excel (Req 20) */}
              <div className="pt-3 border-t border-[rgba(148,163,184,0.1)] flex items-center justify-between text-xs">
                <span className="text-[11px] text-[#64748B] flex items-center gap-1.5 font-mono">
                  <FileText className="w-3.5 h-3.5 text-blue-400" />
                  <span>Click to preview</span>
                </span>

                <div className="flex items-center gap-2">
                  {(['PDF', 'CSV', 'Excel'] as const).map(fmt => (
                    <button
                      key={fmt}
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        handleExport(template.title, fmt);
                      }}
                      className="px-2.5 py-1 text-xs font-semibold text-slate-300 hover:text-white bg-[#0A1424] border border-[rgba(148,163,184,0.2)] hover:border-blue-500/40 rounded-lg transition-colors inline-flex items-center gap-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>{fmt}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Report Data Preview Table (Req 20) */}
      <div className="bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg p-5 space-y-3">
        <div className="flex items-center justify-between pb-3 border-b border-[rgba(148,163,184,0.12)]">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              Live Report Preview: {reportTemplates.find(r => r.id === activeReportId)?.title}
            </h3>
          </div>
          <span className="text-[11px] text-[#94A3B8] font-mono">
            Time Window: {dateRange.toUpperCase()}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#0D1728] border-b border-[rgba(148,163,184,0.12)] text-[11px] font-semibold text-[#94A3B8] uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3">Entity / Location</th>
                <th className="px-4 py-3">Metric Target</th>
                <th className="px-4 py-3">Telemetry Recorded</th>
                <th className="px-4 py-3">Power / SLA Level</th>
                <th className="px-4 py-3 text-right">Audit Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[rgba(148,163,184,0.08)] font-mono">
              {previewData.map((row, idx) => (
                <tr key={idx} className="hover:bg-[#15243B]/40 transition-colors">
                  <td className="px-4 py-3 font-semibold text-[#F8FAFC]">{row.col1}</td>
                  <td className="px-4 py-3 text-slate-300">{row.col2}</td>
                  <td className="px-4 py-3 text-blue-400">{row.col3}</td>
                  <td className="px-4 py-3 text-slate-200">{row.col4}</td>
                  <td className="px-4 py-3 text-right">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      {row.col5}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
