import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Lock,
  Mail,
  Server,
  ShieldCheck,
  ArrowRight,
  ArrowLeft,
  Eye,
  EyeOff,
  Shield,
  CheckCircle2,
  Cpu
} from 'lucide-react';
import { FormField } from '../components/common/FormField';
import { useDataCenter } from '../context/DataContext';
import { BdcLogo } from '../components/common/BdcLogo';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const { users, setCurrentUser } = useDataCenter();
  const [email, setEmail] = useState('rajesh.verma@bharatdc.in');
  const [password, setPassword] = useState('SovereignPass2026!');
  const [facility, setFacility] = useState('MUM-1');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError('Please provide valid account credentials.');
      return;
    }
    setError('');
    setIsLoading(true);

    const matchedUser = users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    const loggedUser = matchedUser || {
      id: 'usr-' + Date.now(),
      fullName: email.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
      name: email.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
      email: email.trim(),
      role: 'Admin' as const,
      assignedDataCenter: facility,
      status: 'Active' as const,
      lastLogin: 'Just now',
      phone: '+91 22 2400 9001'
    };

    setCurrentUser(loggedUser);

    setTimeout(() => {
      setIsLoading(false);
      navigate('/dashboard');
    }, 400);
  };

  const handleRoleQuickSelect = (
    roleEmail: string,
    fac: string,
    roleTitle: string
  ) => {
    setEmail(roleEmail);
    setPassword('SovereignPass2026!');
    setFacility(fac);
    setError('');
  };

  return (
    <div className="min-h-screen bg-[#07111F] relative overflow-hidden flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
      {/* Ambient background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-blue-600/10 via-cyan-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(148,163,184,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(148,163,184,0.03)_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none" />

      <div className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md text-center">
        {/* Return to Platform Landing (Req 23) */}
        <button
          type="button"
          onClick={() => navigate('/')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-[#94A3B8] hover:text-white transition-colors mb-6 group px-3 py-1.5 rounded-lg bg-[#101C30]/80 border border-[rgba(148,163,184,0.15)] hover:border-blue-500/30"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Return to Platform Overview</span>
        </button>

        {/* BharatDC Branding with glowing wordmark (Req 23) */}
        <div className="flex flex-col items-center justify-center mb-6">
          <div className="flex items-center gap-3">
            <BdcLogo size="lg" />
            <h1 className="text-2xl font-bold tracking-tight text-[#F8FAFC]">
              BHARAT<span className="text-blue-500">DC</span>
            </h1>
          </div>
          <p className="mt-2 text-xs text-[#94A3B8] tracking-wide uppercase font-mono">
            Sovereign Cloud & Compute Infrastructure Command
          </p>
        </div>
      </div>

      <div className="relative z-10 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-[#101C30]/90 backdrop-blur-xl py-8 px-6 sm:px-8 border border-[rgba(148,163,184,0.16)] rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.6)]">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs rounded-lg">
                {error}
              </div>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                Staff Identity / Authorized Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  id="login-email-input"
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 font-mono"
                  placeholder="name@bharatdc.in"
                  required
                />
              </div>
            </div>

            {/* Password with Show/Hide Toggle (Req 23) */}
            <div>
              <label className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                Hardware Access Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  id="login-password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full pl-9 pr-10 py-2.5 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 font-mono"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300 p-0.5"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Designated Facility Selection */}
            <div>
              <label className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                Primary Facility Zone
              </label>
              <div className="relative">
                <Server className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <select
                  id="login-facility-select"
                  value={facility}
                  onChange={e => setFacility(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
                >
                  <option value="MUM-1">BHARATDC Mumbai West (MUM-1)</option>
                  <option value="DEL-2">BHARATDC Delhi NCR Core (DEL-2)</option>
                  <option value="BLR-1">BHARATDC Bengaluru Tech Hub (BLR-1)</option>
                  <option value="HYD-1">BHARATDC Hyderabad HITEC (HYD-1)</option>
                  <option value="CHE-1">BHARATDC Chennai Coast (CHE-1)</option>
                </select>
              </div>
            </div>

            {/* Remember Me Checkbox (Req 23) */}
            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 text-[#94A3B8] cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={e => setRememberMe(e.target.checked)}
                  className="w-3.5 h-3.5 rounded text-blue-600 bg-[#0A1424] border-[rgba(148,163,184,0.3)] focus:ring-0"
                />
                <span>Remember session for 12 hours</span>
              </label>
              <span className="text-[11px] text-blue-400 hover:underline cursor-pointer">
                FIPS Token Help
              </span>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                id="login-submit-btn"
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 transition-all shadow-[0_0_20px_rgba(37,99,235,0.4)] disabled:opacity-50"
              >
                {isLoading ? (
                  <span className="inline-flex items-center gap-2">
                    <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Authorizing Operator Session...</span>
                  </span>
                ) : (
                  <>
                    <span>Authenticate & Access Platform</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Role Quick-Selector for Demo Testing (Req 23) */}
          <div className="mt-6 pt-5 border-t border-[rgba(148,163,184,0.12)]">
            <p className="text-[10px] font-bold text-[#94A3B8] uppercase tracking-wider mb-2.5 text-center">
              Quick Role Authentication (Demo Profiles)
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() =>
                  handleRoleQuickSelect(
                    'rajesh.verma@bharatdc.in',
                    'MUM-1',
                    'Super Admin'
                  )
                }
                className="p-2.5 text-left bg-[#0A1424] border border-[rgba(148,163,184,0.14)] hover:border-blue-500/40 rounded-lg transition-colors group"
              >
                <div className="font-semibold text-[#F8FAFC] group-hover:text-blue-400 transition-colors">
                  Super Admin
                </div>
                <div className="text-[10px] text-[#64748B] font-mono mt-0.5">Rajesh Verma (MUM)</div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleRoleQuickSelect(
                    'pooja.kashyap@bharatdc.in',
                    'DEL-2',
                    'DC Manager'
                  )
                }
                className="p-2.5 text-left bg-[#0A1424] border border-[rgba(148,163,184,0.14)] hover:border-blue-500/40 rounded-lg transition-colors group"
              >
                <div className="font-semibold text-[#F8FAFC] group-hover:text-blue-400 transition-colors">
                  DC Operations
                </div>
                <div className="text-[10px] text-[#64748B] font-mono mt-0.5">Pooja K. (DEL)</div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleRoleQuickSelect(
                    'amit.pathak@bharatdc.in',
                    'BLR-1',
                    'Network Engineer'
                  )
                }
                className="p-2.5 text-left bg-[#0A1424] border border-[rgba(148,163,184,0.14)] hover:border-blue-500/40 rounded-lg transition-colors group"
              >
                <div className="font-semibold text-[#F8FAFC] group-hover:text-blue-400 transition-colors">
                  Network Engineer
                </div>
                <div className="text-[10px] text-[#64748B] font-mono mt-0.5">Amit Pathak (BLR)</div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleRoleQuickSelect(
                    'suresh.menon@bharatdc.in',
                    'HYD-1',
                    'Compliance Auditor'
                  )
                }
                className="p-2.5 text-left bg-[#0A1424] border border-[rgba(148,163,184,0.14)] hover:border-blue-500/40 rounded-lg transition-colors group"
              >
                <div className="font-semibold text-[#F8FAFC] group-hover:text-blue-400 transition-colors">
                  Security Auditor
                </div>
                <div className="text-[10px] text-[#64748B] font-mono mt-0.5">Suresh Menon (HYD)</div>
              </button>
            </div>
          </div>
        </div>

        {/* Sovereign Security Badge (Req 23) */}
        <div className="mt-6 text-center text-xs text-[#94A3B8] flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Protected by Sovereign Security Protocol • AES-256 GCM</span>
        </div>
      </div>
    </div>
  );
};
