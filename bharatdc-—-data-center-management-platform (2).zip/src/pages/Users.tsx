import React, { useState, useMemo } from 'react';
import {
  Plus,
  Edit2,
  Trash2,
  User,
  Shield,
  Building,
  Mail,
  Phone,
  Power,
  UserCheck,
  UserX
} from 'lucide-react';
import { useDataCenter } from '../context/DataContext';
import { User as UserType, UserRole } from '../types';
import { StatusBadge } from '../components/common/StatusBadge';
import { SearchFilterBar } from '../components/common/SearchFilterBar';
import { Modal } from '../components/common/Modal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { FormField } from '../components/common/FormField';
import { EmptyState } from '../components/common/EmptyState';

export const UsersPage: React.FC = () => {
  const {
    users,
    organizations,
    dataCenters,
    addUser,
    updateUser,
    deleteUser
  } = useDataCenter();

  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [orgFilter, setOrgFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserType | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<UserType | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'Operator' as UserRole,
    organization: organizations[0]?.name || 'BHARATDC Operations Command',
    phone: '',
    assignedDataCenter: dataCenters[0]?.name || 'All Facilities',
    status: 'Active' as UserType['status']
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      const displayName = u.fullName || u.name || '';
      const orgName = u.organization || '';
      const matchesSearch =
        displayName.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase()) ||
        orgName.toLowerCase().includes(search.toLowerCase()) ||
        u.role.toLowerCase().includes(search.toLowerCase());

      const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
      const matchesOrg = orgFilter === 'ALL' || u.organization === orgFilter;
      const matchesStatus = statusFilter === 'ALL' || u.status === statusFilter;

      return matchesSearch && matchesRole && matchesOrg && matchesStatus;
    });
  }, [users, search, roleFilter, orgFilter, statusFilter]);

  const handleOpenAdd = () => {
    setFormData({
      name: 'Pooja Kulkarni',
      email: 'p.kulkarni@bharatdc.gov.in',
      role: 'Operator',
      organization: organizations[0]?.name || 'BHARATDC Operations Command',
      phone: '+91 22 2400 9922',
      assignedDataCenter: dataCenters[0]?.name || 'All Facilities',
      status: 'Active'
    });
    setFormErrors({});
    setIsAddOpen(true);
  };

  const handleOpenEdit = (user: UserType) => {
    setEditingUser(user);
    setFormData({
      name: user.fullName || user.name || '',
      email: user.email,
      role: user.role,
      organization: user.organization || 'BHARATDC Operations Command',
      phone: user.phone || '',
      assignedDataCenter: user.assignedDataCenter || 'All Facilities',
      status: user.status
    });
    setFormErrors({});
  };

  const handleToggleStatus = (user: UserType) => {
    const nextStatus: UserType['status'] = user.status === 'Active' ? 'Suspended' : 'Active';
    updateUser(user.id, { status: nextStatus });
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) errors.name = 'Please enter a full name.';
    if (!formData.email.trim()) errors.email = 'Please enter an email address.';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    addUser({
      fullName: formData.name.trim(),
      name: formData.name.trim(),
      email: formData.email.trim(),
      role: formData.role as UserRole,
      organization: formData.organization,
      phone: formData.phone.trim(),
      assignedDataCenter: formData.assignedDataCenter,
      status: formData.status
    });

    setIsAddOpen(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser || !validateForm()) return;

    updateUser(editingUser.id, {
      fullName: formData.name.trim(),
      name: formData.name.trim(),
      email: formData.email.trim(),
      role: formData.role as UserRole,
      organization: formData.organization,
      phone: formData.phone.trim(),
      assignedDataCenter: formData.assignedDataCenter,
      status: formData.status
    });

    setEditingUser(null);
  };

  const handleDeleteConfirm = () => {
    if (deleteTarget) {
      deleteUser(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  // Distinct Role Badges (Req 12)
  const renderRoleBadge = (role: string) => {
    switch (role) {
      case 'Super Admin':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold tracking-wide bg-purple-500/15 text-purple-300 border border-purple-500/30">
            <Shield className="w-3 h-3 text-purple-400" />
            <span>Super Admin</span>
          </span>
        );
      case 'Admin':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold tracking-wide bg-blue-500/15 text-blue-300 border border-blue-500/30">
            <Shield className="w-3 h-3 text-blue-400" />
            <span>Admin</span>
          </span>
        );
      case 'Operator':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold tracking-wide bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
            <span>Operator</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold tracking-wide bg-slate-800 text-slate-300 border border-slate-700">
            <span>Viewer</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-base sm:text-lg font-semibold text-[#F8FAFC] tracking-tight">Identity & Access Management</h2>
          <p className="text-xs text-[#94A3B8] mt-0.5">
            Administer personnel roles, multi-tenant organization access, and security privileges
          </p>
        </div>
        <button
          id="add-user-btn"
          type="button"
          onClick={handleOpenAdd}
          className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Add User</span>
        </button>
      </div>

      {/* Search and Filters */}
      <SearchFilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search by personnel name, email, or role..."
        countText={`Showing ${filteredUsers.length} of ${users.length} operators`}
        showReset={search !== '' || roleFilter !== 'ALL' || orgFilter !== 'ALL' || statusFilter !== 'ALL'}
        onResetFilters={() => {
          setSearch('');
          setRoleFilter('ALL');
          setOrgFilter('ALL');
          setStatusFilter('ALL');
        }}
        filters={
          <>
            <select
              value={roleFilter}
              onChange={e => setRoleFilter(e.target.value)}
              className="py-1.5 px-3 text-xs text-slate-200 bg-[#101C30] border border-[rgba(148,163,184,0.2)] rounded-lg focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Roles</option>
              <option value="Super Admin">Super Admin</option>
              <option value="Admin">Admin</option>
              <option value="Operator">Operator</option>
              <option value="Viewer">Viewer</option>
            </select>

            <select
              value={orgFilter}
              onChange={e => setOrgFilter(e.target.value)}
              className="py-1.5 px-3 text-xs text-slate-200 bg-[#101C30] border border-[rgba(148,163,184,0.2)] rounded-lg focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Organizations</option>
              {organizations.map(o => (
                <option key={o.id} value={o.name}>
                  {o.name}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="py-1.5 px-3 text-xs text-slate-200 bg-[#101C30] border border-[rgba(148,163,184,0.2)] rounded-lg focus:ring-1 focus:ring-blue-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Suspended">Suspended</option>
            </select>
          </>
        }
      />

      {/* Users Table (Req 12) */}
      {filteredUsers.length === 0 ? (
        <EmptyState
          title="No users found"
          description="No users match your criteria."
          secondaryActionText="Reset Filters"
          onSecondaryAction={() => {
            setSearch('');
            setRoleFilter('ALL');
            setOrgFilter('ALL');
            setStatusFilter('ALL');
          }}
          actionText="Add User"
          onAction={handleOpenAdd}
        />
      ) : (
        <div className="bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#0D1728] border-b border-[rgba(148,163,184,0.12)] text-[11px] font-semibold text-[#94A3B8] uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3.5">User</th>
                  <th className="px-4 py-3.5">Role</th>
                  <th className="px-4 py-3.5">Organization</th>
                  <th className="px-4 py-3.5">Assigned Facility</th>
                  <th className="px-4 py-3.5">Last Active</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[rgba(148,163,184,0.08)]">
                {filteredUsers.map(user => {
                  const name = user.fullName || user.name || 'User';
                  const initials = name
                    .split(' ')
                    .map(n => n[0])
                    .slice(0, 2)
                    .join('')
                    .toUpperCase();

                  return (
                    <tr key={user.id} className="hover:bg-[#15243B]/40 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-bold text-xs shadow-sm flex-shrink-0">
                            {initials}
                          </div>
                          <div>
                            <div className="font-semibold text-[#F8FAFC]">{name}</div>
                            <div className="text-[11px] text-[#94A3B8] font-mono">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        {renderRoleBadge(user.role)}
                      </td>
                      <td className="px-4 py-3.5 text-slate-200 font-medium">
                        {user.organization || 'Operations Command'}
                      </td>
                      <td className="px-4 py-3.5 text-slate-300 font-mono">
                        {user.assignedDataCenter || 'All Sites'}
                      </td>
                      <td className="px-4 py-3.5 text-[#64748B] font-mono">
                        {user.lastLogin || 'Just now'}
                      </td>
                      <td className="px-4 py-3.5">
                        <StatusBadge status={user.status} />
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(user)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              user.status === 'Active'
                                ? 'text-amber-400 hover:text-amber-300 hover:bg-amber-500/10'
                                : 'text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10'
                            }`}
                            title={user.status === 'Active' ? 'Suspend Access' : 'Activate Access'}
                          >
                            <Power className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(user)}
                            className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-[#15243B] rounded-lg transition-colors"
                            title="Edit User / Role"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(user)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Add User Account"
        description="Provision platform credentials and assign facility access roles"
        maxWidth="lg"
      >
        <form onSubmit={handleSaveAdd} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <FormField id="user-name" label="Full Name" required error={formErrors.name}>
              <input
                id="user-name"
                type="text"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Pooja Kulkarni"
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              />
            </FormField>

            <FormField id="user-email" label="Official Email" required error={formErrors.email}>
              <input
                id="user-email"
                type="email"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                placeholder="pooja@bharatdc.gov.in"
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              />
            </FormField>

            <FormField id="user-role" label="Role Level">
              <select
                id="user-role"
                value={formData.role}
                onChange={e => setFormData({ ...formData, role: e.target.value as UserRole })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              >
                <option value="Super Admin">Super Admin</option>
                <option value="Admin">Admin</option>
                <option value="Operator">Operator</option>
                <option value="Viewer">Viewer</option>
              </select>
            </FormField>

            <FormField id="user-org" label="Organization">
              <select
                id="user-org"
                value={formData.organization}
                onChange={e => setFormData({ ...formData, organization: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              >
                {organizations.map(o => (
                  <option key={o.id} value={o.name}>
                    {o.name}
                  </option>
                ))}
              </select>
            </FormField>

            <FormField id="user-phone" label="Phone Number">
              <input
                id="user-phone"
                type="text"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+91 22 2400 9922"
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 font-mono"
              />
            </FormField>

            <FormField id="user-dc" label="Assigned Data Center">
              <select
                id="user-dc"
                value={formData.assignedDataCenter}
                onChange={e => setFormData({ ...formData, assignedDataCenter: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              >
                <option value="All Facilities">All Facilities</option>
                {dataCenters.map(dc => (
                  <option key={dc.id} value={dc.name}>
                    {dc.name} ({dc.code})
                  </option>
                ))}
              </select>
            </FormField>
          </div>

          <div className="pt-3 border-t border-[rgba(148,163,184,0.12)] flex justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setIsAddOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg hover:bg-[#15243B] hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all shadow-sm"
            >
              Provision User
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit User Modal */}
      <Modal
        isOpen={!!editingUser}
        onClose={() => setEditingUser(null)}
        title="Edit User Profile & Role"
        description={`Update security profile for ${editingUser?.fullName || editingUser?.name}`}
        maxWidth="lg"
      >
        <form onSubmit={handleSaveEdit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <FormField id="edit-user-name" label="Full Name" required error={formErrors.name}>
              <input
                id="edit-user-name"
                type="text"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              />
            </FormField>

            <FormField id="edit-user-email" label="Official Email" required error={formErrors.email}>
              <input
                id="edit-user-email"
                type="email"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              />
            </FormField>

            <FormField id="edit-user-role" label="Role Level">
              <select
                id="edit-user-role"
                value={formData.role}
                onChange={e => setFormData({ ...formData, role: e.target.value as UserRole })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              >
                <option value="Super Admin">Super Admin</option>
                <option value="Admin">Admin</option>
                <option value="Operator">Operator</option>
                <option value="Viewer">Viewer</option>
              </select>
            </FormField>

            <FormField id="edit-user-org" label="Organization">
              <select
                id="edit-user-org"
                value={formData.organization}
                onChange={e => setFormData({ ...formData, organization: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              >
                {organizations.map(o => (
                  <option key={o.id} value={o.name}>
                    {o.name}
                  </option>
                ))}
              </select>
            </FormField>

            <FormField id="edit-user-phone" label="Phone">
              <input
                id="edit-user-phone"
                type="text"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 font-mono"
              />
            </FormField>

            <FormField id="edit-user-dc" label="Assigned Data Center">
              <select
                id="edit-user-dc"
                value={formData.assignedDataCenter}
                onChange={e => setFormData({ ...formData, assignedDataCenter: e.target.value })}
                className="w-full px-3 py-2 text-xs text-[#F8FAFC] bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500"
              >
                <option value="All Facilities">All Facilities</option>
                {dataCenters.map(dc => (
                  <option key={dc.id} value={dc.name}>
                    {dc.name} ({dc.code})
                  </option>
                ))}
              </select>
            </FormField>
          </div>

          <div className="pt-3 border-t border-[rgba(148,163,184,0.12)] flex justify-end gap-2.5">
            <button
              type="button"
              onClick={() => setEditingUser(null)}
              className="px-4 py-2 text-xs font-semibold text-slate-300 bg-[#0A1424] border border-[rgba(148,163,184,0.2)] rounded-lg hover:bg-[#15243B] hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all shadow-sm"
            >
              Save Changes
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        isOpen={!!deleteTarget}
        title="Revoke User Access?"
        message={`This will permanently remove ${deleteTarget?.fullName || deleteTarget?.name} from BHARATDC platform.`}
        confirmText="Revoke User"
        cancelText="Cancel"
        isDestructive={true}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
