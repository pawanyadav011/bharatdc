import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  Server,
  HardDrive,
  Users,
  Building2,
  CheckCircle2,
  Wrench,
  ArrowUpRight,
  Plus,
  Cpu,
  Activity,
  ShieldCheck,
  Zap,
  TrendingUp,
  AlertTriangle,
  Radio,
  Clock,
  Layers
} from 'lucide-react';
import { useDataCenter } from '../context/DataContext';
import { StatusBadge } from '../components/common/StatusBadge';

export const Dashboard: React.FC = () => {
  const {
    stats,
    dataCenters,
    maintenance,
    allocations,
    startMaintenance
  } = useDataCenter();

  const upcomingMaintenance = maintenance
    .filter(m => m.status === 'Scheduled' || m.status === 'In Progress')
    .slice(0, 3);

  const recentAllocations = allocations.slice(0, 5);

  const inUsePercent = Math.round((stats.serversInUse / Math.max(1, stats.totalServers)) * 100);
  const availablePercent = Math.round((stats.availableServers / Math.max(1, stats.totalServers)) * 100);
  const maintenancePercent = Math.round((stats.serversUnderMaintenance / Math.max(1, stats.totalServers)) * 100);
  const notWorkingPercent = Math.round((stats.serversNotWorking / Math.max(1, stats.totalServers)) * 100);

  // Stagger animation container & item variants
  const containerVariants: any = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08
      }
    }
  };

  const itemVariants: any = {
    hidden: { opacity: 0, y: 14 },
    show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" } }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="space-y-6"
    >
      {/* 1. NOC Top Status Bar (Req 6 & 9) */}
      <motion.div
        variants={itemVariants}
        className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 bg-[#101C30] border border-[rgba(148,163,184,0.16)] rounded-xl shadow-lg relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-96 h-full bg-gradient-to-l from-blue-600/5 to-transparent pointer-events-none" />

        <div className="space-y-1.5 z-10">
          <div className="flex items-center gap-3">
            <h2 className="text-base sm:text-lg font-semibold text-[#F8FAFC] tracking-tight">
              Network Operations Center
            </h2>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_8px_rgba(52,211,153,0.2)]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              SYSTEM HEALTHY
            </span>
          </div>
          <p className="text-xs text-[#94A3B8]">
            Supervising <span className="text-[#F8FAFC] font-medium">{stats.totalServers} servers</span> across{' '}
            <span className="text-[#F8FAFC] font-medium">{stats.totalDataCenters} facilities</span> and{' '}
            <span className="text-[#F8FAFC] font-medium">{stats.totalRacks} racks</span> in active tier clusters.
          </p>
        </div>

        {/* Real-time telemetry pills & Quick Actions */}
        <div className="flex flex-wrap items-center gap-3 z-10">
          <div className="hidden sm:flex items-center gap-3 px-3 py-1.5 bg-[#0A1424] border border-[rgba(148,163,184,0.12)] rounded-lg text-xs">
            <div className="flex items-center gap-1.5 text-slate-300 font-mono">
              <Activity className="w-3.5 h-3.5 text-blue-400" />
              <span>99.995% Uptime</span>
            </div>
            <div className="w-[1px] h-3 bg-slate-700" />
            <div className="flex items-center gap-1.5 text-slate-300 font-mono">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>PUE 1.18</span>
            </div>
          </div>

          <Link
            to="/servers"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-200 bg-[#122038] border border-[rgba(148,163,184,0.2)] rounded-lg hover:bg-[#15243B] hover:text-white transition-colors"
          >
            <Server className="w-3.5 h-3.5 text-blue-400" />
            <span>Servers</span>
          </Link>
          <Link
            to="/server-allocation"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all shadow-[0_0_12px_rgba(37,99,235,0.3)]"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Allocate Server</span>
          </Link>
        </div>
      </motion.div>

      {/* 2. KPI Metric Cards (Req 9 & 10) */}
      <motion.div
        variants={itemVariants}
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4"
      >
        {/* Total Data Centers */}
        <div className="group relative p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-sm hover:border-blue-500/40 hover:shadow-[0_0_15px_rgba(37,99,235,0.1)] transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#94A3B8]">Data Centers</span>
            <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Building2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-[#F8FAFC] tracking-tight">{stats.totalDataCenters}</div>
          <div className="mt-1 flex items-center justify-between text-[10px]">
            <span className="text-[#64748B]">Operational</span>
            <span className="text-emerald-400 font-mono font-medium">100% Online</span>
          </div>
        </div>

        {/* Total Racks */}
        <div className="group relative p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-sm hover:border-blue-500/40 hover:shadow-[0_0_15px_rgba(37,99,235,0.1)] transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#94A3B8]">Total Racks</span>
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Layers className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-[#F8FAFC] tracking-tight">{stats.totalRacks}</div>
          <div className="mt-1 flex items-center justify-between text-[10px]">
            <span className="text-[#64748B]">42U Density</span>
            <span className="text-indigo-400 font-mono font-medium">84% Cap</span>
          </div>
        </div>

        {/* Total Servers */}
        <div className="group relative p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-sm hover:border-blue-500/40 hover:shadow-[0_0_15px_rgba(37,99,235,0.1)] transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#94A3B8]">Total Servers</span>
            <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <Server className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-[#F8FAFC] tracking-tight">{stats.totalServers}</div>
          <div className="mt-1 flex items-center justify-between text-[10px]">
            <span className="text-[#64748B]">Inventory</span>
            <span className="text-blue-400 font-mono font-medium">+4.2% MoM</span>
          </div>
        </div>

        {/* Available Servers */}
        <div className="group relative p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-sm hover:border-emerald-500/40 hover:shadow-[0_0_15px_rgba(52,211,153,0.1)] transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-400">Available</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-emerald-400 tracking-tight">{stats.availableServers}</div>
          <div className="mt-1 flex items-center justify-between text-[10px]">
            <span className="text-[#64748B]">Ready for task</span>
            <span className="text-emerald-400 font-mono font-medium">{availablePercent}% Free</span>
          </div>
        </div>

        {/* In Use Servers */}
        <div className="group relative p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-sm hover:border-blue-500/40 hover:shadow-[0_0_15px_rgba(37,99,235,0.1)] transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-blue-400">In Use</span>
            <div className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <HardDrive className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-blue-400 tracking-tight">{stats.serversInUse}</div>
          <div className="mt-1 flex items-center justify-between text-[10px]">
            <span className="text-[#64748B]">Allocated</span>
            <span className="text-blue-400 font-mono font-medium">{inUsePercent}% Active</span>
          </div>
        </div>

        {/* Maintenance Servers */}
        <div className="group relative p-4 bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-sm hover:border-amber-500/40 hover:shadow-[0_0_15px_rgba(245,158,11,0.1)] transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400">Maintenance</span>
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Wrench className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-amber-400 tracking-tight">{stats.serversUnderMaintenance}</div>
          <div className="mt-1 flex items-center justify-between text-[10px]">
            <span className="text-[#64748B]">Active checks</span>
            <span className="text-amber-400 font-mono font-medium">{maintenancePercent}% In Prog</span>
          </div>
        </div>
      </motion.div>

      {/* 3. Primary Charts & Data Center Status (Req 6 & 9) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Server Status Distribution & Recent Allocations */}
        <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
          {/* Server Status Distribution Card */}
          <div className="bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[rgba(148,163,184,0.12)] bg-[#122038]/60">
              <div>
                <h3 className="text-sm font-semibold text-[#F8FAFC]">Server Capacity & Status Distribution</h3>
                <p className="text-xs text-[#94A3B8] mt-0.5">
                  Real-time cluster breakdown across enterprise racks
                </p>
              </div>
              <Link
                to="/servers"
                className="text-xs text-blue-400 hover:text-blue-300 font-medium inline-flex items-center gap-1 transition-colors"
              >
                <span>View Inventory</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            {/* Distribution Bar */}
            <div className="p-5 border-b border-[rgba(148,163,184,0.1)] bg-[#0D1728]/40">
              <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-2.5 font-medium">
                <span className="flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-blue-400" />
                  Cluster Utilization Level
                </span>
                <span className="text-[#F8FAFC] font-semibold font-mono">{inUsePercent}% In Production</span>
              </div>

              {/* Visual Status Bar */}
              <div className="w-full h-3 rounded-full bg-[#07111F] overflow-hidden flex border border-[rgba(148,163,184,0.12)] p-0.5">
                <div
                  style={{ width: `${(stats.serversInUse / Math.max(1, stats.totalServers)) * 100}%` }}
                  className="bg-blue-500 rounded-l-full h-full shadow-[0_0_8px_rgba(59,130,246,0.6)] transition-all duration-500"
                  title={`In Use: ${stats.serversInUse}`}
                />
                <div
                  style={{ width: `${(stats.availableServers / Math.max(1, stats.totalServers)) * 100}%` }}
                  className="bg-emerald-500 h-full shadow-[0_0_8px_rgba(52,211,153,0.6)] transition-all duration-500"
                  title={`Available: ${stats.availableServers}`}
                />
                <div
                  style={{ width: `${(stats.serversUnderMaintenance / Math.max(1, stats.totalServers)) * 100}%` }}
                  className="bg-amber-500 h-full shadow-[0_0_8px_rgba(245,158,11,0.6)] transition-all duration-500"
                  title={`Maintenance: ${stats.serversUnderMaintenance}`}
                />
                <div
                  style={{ width: `${(stats.serversNotWorking / Math.max(1, stats.totalServers)) * 100}%` }}
                  className="bg-rose-500 rounded-r-full h-full shadow-[0_0_8px_rgba(244,63,94,0.6)] transition-all duration-500"
                  title={`Not Working: ${stats.serversNotWorking}`}
                />
              </div>

              {/* Metrics Legend */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3.5 border-t border-[rgba(148,163,184,0.1)] text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-sm bg-blue-500 shadow-[0_0_4px_rgba(59,130,246,0.8)] shrink-0" />
                  <span className="text-[#94A3B8]">
                    In Use: <b className="text-[#F8FAFC]">{stats.serversInUse}</b> ({inUsePercent}%)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 shadow-[0_0_4px_rgba(52,211,153,0.8)] shrink-0" />
                  <span className="text-[#94A3B8]">
                    Available: <b className="text-[#F8FAFC]">{stats.availableServers}</b> ({availablePercent}%)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 shadow-[0_0_4px_rgba(245,158,11,0.8)] shrink-0" />
                  <span className="text-[#94A3B8]">
                    Maintenance: <b className="text-[#F8FAFC]">{stats.serversUnderMaintenance}</b> ({maintenancePercent}%)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-sm bg-rose-500 shadow-[0_0_4px_rgba(244,63,94,0.8)] shrink-0" />
                  <span className="text-[#94A3B8]">
                    Defective: <b className="text-[#F8FAFC]">{stats.serversNotWorking}</b> ({notWorkingPercent}%)
                  </span>
                </div>
              </div>
            </div>

            {/* Operating Data Centers List */}
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-semibold text-[#94A3B8] uppercase tracking-wider">
                  Operating Data Centers
                </h4>
                <Link to="/data-centers" className="text-xs text-blue-400 hover:text-blue-300 font-medium">
                  Manage Facilities →
                </Link>
              </div>
              <div className="divide-y divide-[rgba(148,163,184,0.08)]">
                {dataCenters.map(dc => (
                  <div key={dc.id} className="py-3 flex items-center justify-between text-xs hover:bg-[#15243B]/40 px-2 rounded-lg transition-colors">
                    <div>
                      <span className="font-semibold text-[#F8FAFC]">{dc.name}</span>
                      <span className="text-[#64748B] ml-2 font-mono">({dc.city})</span>
                    </div>
                    <div className="flex items-center gap-4 font-mono">
                      <span className="text-[#94A3B8] text-[11px]">
                        {dc.totalRacks} Racks • {dc.powerCapacityKw} kW
                      </span>
                      <StatusBadge status={dc.status} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Server Allocations Card */}
          <div className="bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[rgba(148,163,184,0.12)] bg-[#122038]/60">
              <div>
                <h3 className="text-sm font-semibold text-[#F8FAFC]">Recent Server Allocations</h3>
                <p className="text-xs text-[#94A3B8] mt-0.5">
                  Latest verified assignments and provisioned compute instances
                </p>
              </div>
              <Link
                to="/server-allocation"
                className="text-xs text-blue-400 hover:text-blue-300 font-medium inline-flex items-center gap-1 transition-colors"
              >
                <span>View All</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="divide-y divide-[rgba(148,163,184,0.08)] text-xs">
              {recentAllocations.map(alloc => (
                <div key={alloc.id} className="p-4 flex items-center justify-between hover:bg-[#15243B]/50 transition-colors">
                  <div>
                    <div className="font-semibold text-[#F8FAFC]">{alloc.clientName}</div>
                    <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5">
                      {alloc.assetTag} • <span className="text-blue-400">{alloc.purpose}</span>
                    </div>
                  </div>
                  <div className="text-right font-mono">
                    <span className="font-medium text-slate-300 block">{alloc.dataCenterName}</span>
                    <span className="text-[11px] text-[#64748B]">{alloc.assignedDate}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Right Column: Quick Actions & Maintenance */}
        <motion.div variants={itemVariants} className="space-y-6">
          {/* Quick Actions (Req 6 & 9) */}
          <div className="bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg p-5 space-y-3">
            <h4 className="text-xs font-semibold text-[#94A3B8] uppercase tracking-wider">
              Quick Actions
            </h4>
            <div className="space-y-2">
              <Link
                to="/servers"
                className="flex items-center justify-between p-3 rounded-lg border border-[rgba(148,163,184,0.14)] bg-[#0D1728]/70 hover:border-blue-500/40 hover:bg-[#15243B] transition-all text-xs group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20">
                    <Server className="w-4 h-4" />
                  </div>
                  <span className="font-medium text-slate-200 group-hover:text-white">Add Server</span>
                </div>
                <Plus className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors" />
              </Link>

              <Link
                to="/server-allocation"
                className="flex items-center justify-between p-3 rounded-lg border border-[rgba(148,163,184,0.14)] bg-[#0D1728]/70 hover:border-blue-500/40 hover:bg-[#15243B] transition-all text-xs group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <span className="font-medium text-slate-200 group-hover:text-white">Allocate Server</span>
                </div>
                <Plus className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors" />
              </Link>

              <Link
                to="/maintenance"
                className="flex items-center justify-between p-3 rounded-lg border border-[rgba(148,163,184,0.14)] bg-[#0D1728]/70 hover:border-blue-500/40 hover:bg-[#15243B] transition-all text-xs group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
                    <Wrench className="w-4 h-4" />
                  </div>
                  <span className="font-medium text-slate-200 group-hover:text-white">Schedule Maintenance</span>
                </div>
                <Plus className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
              </Link>

              <Link
                to="/clients"
                className="flex items-center justify-between p-3 rounded-lg border border-[rgba(148,163,184,0.14)] bg-[#0D1728]/70 hover:border-blue-500/40 hover:bg-[#15243B] transition-all text-xs group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500/20">
                    <Users className="w-4 h-4" />
                  </div>
                  <span className="font-medium text-slate-200 group-hover:text-white">Add Client</span>
                </div>
                <Plus className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-colors" />
              </Link>
            </div>
          </div>

          {/* Upcoming Maintenance Tasks (Req 9) */}
          <div className="bg-[#101C30] border border-[rgba(148,163,184,0.14)] rounded-xl shadow-lg overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-[rgba(148,163,184,0.12)] bg-[#122038]/60">
              <div>
                <h3 className="text-sm font-semibold text-[#F8FAFC]">Upcoming Maintenance</h3>
                <p className="text-xs text-[#94A3B8] mt-0.5">
                  Scheduled technician inspections
                </p>
              </div>
              <Link
                to="/maintenance"
                className="text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors"
              >
                View All
              </Link>
            </div>

            <div className="p-4 space-y-3">
              {upcomingMaintenance.length === 0 ? (
                <p className="text-xs text-[#94A3B8] text-center py-6">
                  No upcoming maintenance scheduled.
                </p>
              ) : (
                upcomingMaintenance.map(task => (
                  <div
                    key={task.id}
                    className="p-3 bg-[#0D1728]/80 border border-[rgba(148,163,184,0.12)] rounded-lg text-xs space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-semibold text-[#F8FAFC] leading-snug">
                        {task.title}
                      </span>
                      <StatusBadge status={task.status} />
                    </div>
                    <div className="text-[#94A3B8] text-[11px] space-y-1 font-mono">
                      <div>Data Center: <span className="text-slate-300 font-medium">{task.dataCenterName}</span></div>
                      <div>Technician: <span className="text-slate-300 font-medium">{task.technician}</span></div>
                      <div className="text-[#64748B] pt-0.5">{task.scheduledDate}</div>
                    </div>
                    {task.status === 'Scheduled' && (
                      <button
                        type="button"
                        onClick={() => startMaintenance(task.id)}
                        className="w-full mt-1.5 py-1.5 text-center text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
                      >
                        Start Task
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};
